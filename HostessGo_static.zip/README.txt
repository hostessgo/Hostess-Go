
# HostessGo (versione gratuita - static web app)

Questo pacchetto contiene una semplice web-app statica che funge da interfaccia per HostessGo.
L'app usa Google Forms e Google Sheets come database gratuito e richiede pochi passi manuali per essere operativa.

## Cosa c'è nella cartella
- index.html → Home (pulsanti)
- hostess.html → pagina per Hostess (incolla link Google Form)
- company.html → pagina per Aziende (incolla link Google Form)
- admin.html → istruzioni e campi consigliati
- styles.css → stile grafico (rosa cipria / bianco / nero)
- logo.svg → logo semplice
- README.txt → questo file

## Come attivare (in 10 minuti)
1. Crea due Google Forms (Hostess + Azienda) con i campi suggeriti in admin.html.
2. In ciascun modulo vai su Risposte → crea Foglio di lavoro. Salva gli Sheet per visualizzare le candidature/annunci.
3. Copia il link del modulo (Condividi → Copia link).
4. Apri il file hostess.html nel browser (o carica tutto online) e incolla il link del modulo nel campo e premi "Salva link".
   Ripeti per company.html.
5. Per pubblicare online gratuitamente: carica tutta la cartella su GitHub e attiva GitHub Pages, oppure caricala su Netlify.
   - GitHub Pages: https://pages.github.com
   - Netlify drag & drop: https://app.netlify.com/drop

## Suggerimenti
- Condividi il link GitHub Pages con il tuo gruppo di hostess e con le aziende.
- Per gestire candidature: apri Google Sheets e filtra/ordina come preferisci.
- Se vuoi integrare pagamenti in futuro, useremo Stripe Connect quando passerai alla versione a pagamento.

Se vuoi, ora posso:
- generare un file zip con tutti i file pronti (lo faccio qui e te lo passo),
- oppure spiegarti passo passo come creare i Google Forms in chat.
