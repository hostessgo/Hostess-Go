function saluta() {
  alert("Ciao Bea 🌙✨, la tua app funziona!");
}